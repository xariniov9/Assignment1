var bodyParser = require('body-parser');
var express = require('express');

var app = express();

app.use('/', bodyParser.urlencoded({extended : false}));

app.use("/static", express.static(__dirname + "/static"));

app.post('/submit', function (req, res) {
    var dob = new Date(req.body.yyyy, req.body.mm - 1, req.body.dd, 5, 30, 1);
    console.log(dob);
    var curDt = new Date();

    var numDays = Math.round((curDt.getTime() - dob.getTime())/(1000 * 60 * 60 * 24))
   res.send("Thank you " + req.body.name + " You have lived for " + numDays + " days!");
});

app.listen(3000, function(){
    console.log("server working lol!");
});
